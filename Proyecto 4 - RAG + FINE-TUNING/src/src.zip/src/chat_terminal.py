from rag_hibrido import consultar_rag_hibrido

print("\n==============================")
print(" TUTOR ANALÍTICO HÍBRIDO RAG ")
print("==============================")

while True:

    pregunta = input("\nPregunta: ")

    if pregunta.lower() in ["salir", "exit", "quit"]:
        print("\nCerrando tutor...")
        break

    respuesta, fuentes, relevantes, metricas = consultar_rag_hibrido(pregunta)

    print("\n==============================")
    print("RESPUESTA DEL TUTOR")
    print("==============================\n")

    print(respuesta)

    print("\n==============================")
    print("MÉTRICAS")
    print("==============================\n")

    for clave, valor in metricas.items():
        print(f"{clave}: {valor}")

    print("\n==============================")
    print("FUENTES RECUPERADAS")
    print("==============================\n")

    if not relevantes:
        print("No se recuperaron fuentes relevantes.")
    else:
        for f in relevantes:

            print(f"[PDF]: {f['pdf']}")
            print(f"[Página]: {f['pagina']}")
            print(f"[Coincidencias]: {f['coincidencias']}")

            texto = f["texto"][:300]

            print(f"[Fragmento]: {texto}...")
            print("\n-----------------------------")
