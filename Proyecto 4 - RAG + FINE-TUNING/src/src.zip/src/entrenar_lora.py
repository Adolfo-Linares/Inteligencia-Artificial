import os
from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments
from peft import LoraConfig, get_peft_model, TaskType
from trl import SFTTrainer

MODELO_BASE = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
DATASET = "data/finetuning_dataset_train_2000.jsonl"
SALIDA = "modelo_finetuned"

os.makedirs(SALIDA, exist_ok=True)

dataset = load_dataset(
    "json",
    data_files=DATASET,
    split="train"
)

tokenizer = AutoTokenizer.from_pretrained(MODELO_BASE)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

def formatear_ejemplo(ejemplo):
    instruccion = ejemplo.get("instruction", "")
    entrada = ejemplo.get("input", "")
    salida = ejemplo.get("output", "")

    texto = f"""### Instrucción:
{instruccion}

### Entrada:
{entrada}

### Respuesta:
{salida}"""

    tokens = tokenizer(
        texto,
        truncation=True,
        padding="max_length",
        max_length=256
    )

    tokens["labels"] = tokens["input_ids"].copy()

    return tokens

dataset_tokenizado = dataset.map(
    formatear_ejemplo,
    remove_columns=dataset.column_names
)

modelo = AutoModelForCausalLM.from_pretrained(
    MODELO_BASE,
    device_map="cpu",
    low_cpu_mem_usage=True
)

config_lora = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type=TaskType.CAUSAL_LM
)

modelo = get_peft_model(modelo, config_lora)

argumentos = TrainingArguments(
    output_dir=SALIDA,
    per_device_train_batch_size=1,
    gradient_accumulation_steps=1,
    num_train_epochs=1,
    learning_rate=2e-4,
    logging_steps=20,
    save_strategy="epoch",
    fp16=False,
    report_to="none"
)

trainer = SFTTrainer(
    model=modelo,
    train_dataset=dataset_tokenizado,
    args=argumentos
)

trainer.train()

modelo.save_pretrained(SALIDA)
tokenizer.save_pretrained(SALIDA)

print("Fine-Tuning LoRA terminado.")
print("Adaptador guardado en:", SALIDA)
