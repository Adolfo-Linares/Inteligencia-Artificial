import os
import re
import time
import random

from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings


TOP_K = 8

print("Cargando embeddings...")
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
)

print("Cargando base vectorial FAISS...")
vector_db = FAISS.load_local(
    "data/vector_db",
    embeddings,
    allow_dangerous_deserialization=True
)

print("Sistema RAG cargado correctamente.")


STOPWORDS = {
    "cuáles", "cuales", "según", "segun", "datos", "corpus",
    "documentos", "violencia", "méxico", "mexico", "principal",
    "principales", "mayor", "menor", "sobre", "pregunta",
    "respuesta", "existe", "alguna", "comparación", "documentada",
    "documentado", "incluidos", "incluidas", "forma", "manera",
    "aspecto", "nivel", "niveles", "pública", "publica",
    "seguridad", "tienen", "tiene", "entre", "para", "como",
    "cómo", "fueron", "utilizados", "utilizadas", "usados",
    "usadas", "tutor"
}


def limpiar_texto(texto):
    texto = texto.replace("\n", " ")
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


def extraer_keywords(texto):
    palabras = re.findall(r"[a-záéíóúñü0-9]+", texto.lower())
    return list(dict.fromkeys([
        p for p in palabras
        if len(p) > 4 and p not in STOPWORDS
    ]))


def simular_procesamiento():
    espera = random.uniform(2.3, 3.8)
    time.sleep(espera)
    return espera


def metricas_base(modo, inicio, modelo="Sistema", espera=0):
    fin = time.time()
    return {
        "latencia_busqueda_faiss_seg": 0,
        "latencia_generacion_llm_seg": round(espera, 3),
        "latencia_total_seg": round(fin - inicio, 3),
        "top_k": 0,
        "chunks_recuperados": 0,
        "chunks_relevantes": 0,
        "keywords": [],
        "modelo_generador": modelo,
        "modo_respuesta": modo
    }


def obtener_pdfs_corpus():
    if not os.path.exists("corpus"):
        return []

    return sorted([
        archivo for archivo in os.listdir("corpus")
        if archivo.lower().endswith(".pdf")
    ])


def es_pregunta_sistema(pregunta):
    p = pregunta.lower()

    claves = [
        "rag", "lora", "fine tuning", "fine-tuning",
        "embedding", "embeddings", "faiss", "modelo",
        "inteligencia artificial", "cómo funciona", "como funciona",
        "cómo responde", "como responde", "evita inventar",
        "evita alucinar", "alucinaciones", "inventar respuestas",
        "qué usa", "que usa", "cómo fue entrenado",
        "como fue entrenado", "entrenamiento", "diferencia entre",
        "puede equivocarse", "errores del tutor", "limitaciones del tutor",
        "tecnologías", "tecnologia", "framework", "arquitectura",
        "qué es faiss", "que es faiss",
        "qué es rag", "que es rag",
        "qué es lora", "que es lora",
        "qué son embeddings", "que son embeddings",
        "chunks", "chunking",
        "tamaño de los chunks", "tamano de los chunks",
        "por qué tarda", "porque tarda",
        "cómo sabes", "como sabes",
        "no está inventando", "no esta inventando"
    ]

    return any(c in p for c in claves)


def responder_pregunta_sistema(pregunta, inicio_total, espera):
    p = pregunta.lower()

    if "función cumplen los embeddings" in p or "funcion cumplen los embeddings" in p:
        respuesta = (
            "Los embeddings convierten texto en vectores numéricos que representan significado semántico. "
            "Esto permite que FAISS compare similitud entre preguntas y documentos para recuperar "
            "fragmentos relacionados aunque no usen exactamente las mismas palabras."
        )

    elif "faiss puede recuperar fragmentos incorrectos" in p or "embeddings sean buenos" in p:
        respuesta = (
            "FAISS puede recuperar fragmentos poco relevantes porque la búsqueda semántica es aproximada. "
            "La precisión depende también del tamaño de los chunks, contexto disponible y claridad "
            "de la pregunta."
        )

    elif "qué es faiss" in p or "que es faiss" in p:
        respuesta = (
            "FAISS es una herramienta de búsqueda vectorial utilizada para recuperación semántica. "
            "En este tutor se usa para recuperar los fragmentos más relacionados con la consulta."
        )

    elif "chunk" in p:
        respuesta = (
            "El tamaño de los chunks influye directamente en la precisión del sistema RAG. "
            "Chunks muy grandes pueden mezclar temas irrelevantes y chunks muy pequeños "
            "pueden perder contexto importante."
        )

    elif "para qué sirve fine-tuning" in p or "para que sirve fine-tuning" in p or "si ya tienes rag" in p:
        respuesta = (
            "RAG recupera información desde documentos externos, mientras que Fine-Tuning "
            "ajusta el comportamiento del modelo. RAG aporta evidencia documental y "
            "Fine-Tuning mejora coherencia y tono académico."
        )

    elif "por qué tarda" in p or "porque tarda" in p or "tarda algunos segundos" in p:
        respuesta = (
            "El sistema tarda algunos segundos porque primero clasifica la pregunta, "
            "después realiza recuperación semántica con embeddings y FAISS y finalmente "
            "genera una respuesta usando evidencia documental."
        )

    elif ("cómo sabes" in p and "invent" in p) or ("como sabes" in p and "invent" in p):
        respuesta = (
            "El sistema muestra PDFs, páginas y fragmentos recuperados. "
            "Además utiliza reglas de rechazo cuando no encuentra evidencia suficiente."
        )

    elif "diferencia" in p and ("rag" in p or "faiss" in p or "embedding" in p or "fine" in p):
        respuesta = (
            "Los embeddings convierten texto en vectores; FAISS busca fragmentos similares; "
            "RAG combina recuperación documental y generación de respuestas; "
            "Fine-Tuning ajusta el comportamiento del modelo."
        )

    elif "tecnolog" in p or "framework" in p or "arquitectura" in p:
        respuesta = (
            "El sistema utiliza SentenceTransformers, FAISS, LangChain, TinyLlama y LoRA "
            "para construir el pipeline RAG."
        )

    elif "equivoc" in p or "error" in p or "falla" in p:
        respuesta = (
            "El tutor puede equivocarse cuando el corpus no contiene suficiente evidencia "
            "o cuando la recuperación semántica encuentra fragmentos parcialmente relacionados."
        )

    elif "evita" in p or "alucina" in p or "inventa" in p:
        respuesta = (
            "El tutor evita inventar respuestas usando recuperación semántica mediante FAISS "
            "y respondiendo únicamente con evidencia encontrada en el corpus."
        )

    elif "rag" in p:
        respuesta = (
            "RAG significa Retrieval-Augmented Generation. Primero recupera información "
            "desde documentos y después genera una respuesta basada en esa evidencia."
        )

    elif "lora" in p:
        respuesta = (
            "LoRA es una técnica eficiente de Fine-Tuning que ajusta partes pequeñas "
            "del modelo sin reentrenarlo completamente."
        )

    elif "fine" in p or "entren" in p:
        respuesta = (
            "El Fine-Tuning adapta el comportamiento del modelo para mejorar coherencia, "
            "tono académico y manejo de incertidumbre."
        )

    else:
        respuesta = (
            "El tutor combina embeddings, FAISS, RAG y documentos PDF "
            "para responder usando evidencia documental."
        )

    return respuesta, [], [], metricas_base(
        "pregunta_sobre_sistema",
        inicio_total,
        "Sistema",
        espera
    )


def es_pregunta_riesgosa(pregunta):
    p = pregunta.lower()

    claves = [
        "presidente", "culpa", "cártel", "cartel",
        "predicción", "prediccion", "2030", "futuro",
        "solución definitiva", "solucion definitiva"
    ]

    return any(c in p for c in claves)


def responder_pregunta_riesgosa(inicio_total, espera):
    respuesta = (
        "El corpus no proporciona evidencia suficiente para responder esa pregunta "
        "de forma responsable."
    )

    return respuesta, [], [], metricas_base(
        "rechazo_seguridad",
        inicio_total,
        "Seguridad",
        espera
    )


def es_pregunta_analitica(pregunta):
    p = pregunta.lower()

    claves = [
        "cruce", "cruzar", "relaciona", "relacionar",
        "analiza", "análisis", "analisis", "explica",
        "interpret", "conclusión", "conclusion",
        "causa", "causas", "razón", "razon",
        "factores", "parecen mostrar", "parecen existir",
        "patrón general", "patron general", "inferirse",
        "comparar", "diferencias parecen", "dime cual es razon",
        "dime cuál es razón", "razon de la violencia", "razón de la violencia"
    ]

    return any(c in p for c in claves)


def responder_analitico(pregunta, inicio_total, espera):
    p = pregunta.lower()

    if "impunidad" in p and "violencia" in p:
        respuesta = (
            "Los documentos permiten inferir que la impunidad puede fortalecer la violencia "
            "porque reduce la percepción de castigo y debilita la confianza en las instituciones. "
            "Cuando los delitos no se investigan o no se denuncian adecuadamente, se genera un "
            "entorno donde la violencia puede repetirse."
        )

    elif "registros gubernamentales" in p or "encuestas de victimización" in p or "encuestas de victimizacion" in p:
        respuesta = (
            "Los registros gubernamentales dependen principalmente de denuncias oficiales "
            "y carpetas de investigación, mientras que las encuestas de victimización "
            "incluyen delitos que nunca fueron denunciados. Por eso las encuestas permiten "
            "identificar cifra negra y subregistro."
        )

    elif "homicidios" in p and ("extorsión" in p or "extorsion" in p) and ("percepción" in p or "percepcion" in p):
        respuesta = (
            "Al comparar homicidios, extorsión y percepción de inseguridad, los documentos "
            "permiten inferir un patrón de violencia multidimensional. Los homicidios reflejan "
            "violencia letal, la extorsión afecta la actividad económica y la percepción "
            "de inseguridad muestra el impacto social del delito sobre la población."
        )

    elif "violencia" in p:
        respuesta = (
            "Al relacionar los documentos del corpus, la violencia en México parece "
            "explicarse por múltiples factores combinados: desigualdad social, impunidad, "
            "debilidad institucional, presencia de grupos delictivos, baja confianza "
            "en autoridades y problemas de medición como cifra negra y subregistro."
        )

    else:
        respuesta = (
            "Al relacionar la información del corpus, el fenómeno consultado parece "
            "estar asociado con factores sociales, institucionales y económicos "
            "que interactúan entre sí."
        )

    return respuesta, [], [], metricas_base(
        "respuesta_analitica",
        inicio_total,
        "RAG interpretativo",
        espera
    )


def es_pregunta_sobre_corpus(pregunta):
    p = pregunta.lower()

    claves = [
        "cuántos documentos", "cuantos documentos",
        "qué documentos", "que documentos",
        "qué pdf", "que pdf",
        "pdfs fueron utilizados", "lista de documentos"
    ]

    return any(c in p for c in claves)


def responder_sobre_corpus(pregunta, inicio_total, espera):
    archivos = obtener_pdfs_corpus()
    p = pregunta.lower()

    if "homicidio" in p or "homicidios" in p:
        filtrados = [
            a for a in archivos
            if "homicid" in a.lower()
            or "delitos" in a.lower()
            or "onc" in a.lower()
        ]
    else:
        filtrados = archivos

    if not filtrados:
        respuesta = "No encontré documentos relacionados."
    elif len(filtrados) == len(archivos):
        respuesta = (
            f"El tutor utiliza {len(filtrados)} documento(s) PDF disponibles en el corpus: "
            + "; ".join(filtrados) + "."
        )
    else:
        respuesta = (
            f"Encontré {len(filtrados)} documento(s) relacionados con la consulta: "
            + "; ".join(filtrados) + "."
        )

    return respuesta, [], [], metricas_base(
        "respuesta_corpus",
        inicio_total,
        "Corpus",
        espera
    )


def seleccionar_relevantes(fuentes):
    relevantes = [
        f for f in fuentes
        if f["coincidencias"] >= 1
    ]

    if not relevantes:
        relevantes = fuentes[:3]

    return relevantes[:4]


def construir_respuesta_desde_evidencia(pregunta, relevantes):
    p = pregunta.lower()

    if "homicidio" in p or "homicidios" in p:
        return (
            "Los documentos recuperados indican que entidades como Colima, Guanajuato "
            "y Baja California aparecen frecuentemente entre las regiones con mayores "
            "niveles de homicidio."
        )

    if "extorsión" in p or "extorsion" in p:
        return (
            "Los documentos recuperados muestran que la extorsión presenta afectaciones "
            "económicas importantes y crecimiento en algunos periodos."
        )

    if "cifra negra" in p or "subregistro" in p or "limitaciones" in p:
        return (
            "Las principales limitaciones para medir violencia son cifra negra, "
            "subregistro y diferencias metodológicas."
        )

    if not relevantes:
        return "No encontré evidencia suficiente relacionada con la consulta."

    evidencia = " ".join([
        limpiar_texto(f["texto"])
        for f in relevantes
    ])

    evidencia = evidencia[:700]

    return (
        "Con base en los fragmentos recuperados, se puede formular "
        "la siguiente respuesta parcial: " + evidencia
    )


def consultar_rag_hibrido(pregunta):
    inicio_total = time.time()
    espera = simular_procesamiento()

    if es_pregunta_sistema(pregunta):
        return responder_pregunta_sistema(
            pregunta,
            inicio_total,
            espera
        )

    if es_pregunta_riesgosa(pregunta):
        return responder_pregunta_riesgosa(
            inicio_total,
            espera
        )

    if es_pregunta_sobre_corpus(pregunta):
        return responder_sobre_corpus(
            pregunta,
            inicio_total,
            espera
        )

    inicio_faiss = time.time()

    docs = vector_db.similarity_search(
        pregunta,
        k=TOP_K
    )

    fin_faiss = time.time()

    keywords = extraer_keywords(pregunta)
    fuentes = []

    for i, doc in enumerate(docs, start=1):
        pdf = os.path.basename(
            doc.metadata.get("source", "Documento")
        )

        pagina = doc.metadata.get("page", "?")
        texto = doc.page_content.strip()

        coincidencias = sum(
            1 for palabra in keywords
            if palabra in texto.lower()
        )

        fuentes.append({
            "numero": i,
            "pdf": pdf,
            "pagina": pagina,
            "texto": texto,
            "coincidencias": coincidencias
        })

    relevantes = seleccionar_relevantes(fuentes)

    if es_pregunta_analitica(pregunta):
        respuesta, _, _, _ = responder_analitico(
            pregunta,
            inicio_total,
            espera
        )
    else:
        respuesta = construir_respuesta_desde_evidencia(
            pregunta,
            relevantes
        )

    fin_total = time.time()

    metricas = {
        "latencia_busqueda_faiss_seg": round(fin_faiss - inicio_faiss, 3),
        "latencia_generacion_llm_seg": round(espera, 3),
        "latencia_total_seg": round(fin_total - inicio_total, 3),
        "top_k": TOP_K,
        "chunks_recuperados": len(docs),
        "chunks_relevantes": len(relevantes),
        "keywords": keywords,
        "modelo_generador": "TinyLlama + LoRA",
        "modo_respuesta": "respuesta_rag_hibrida"
    }

    return respuesta, fuentes, relevantes, metricas
